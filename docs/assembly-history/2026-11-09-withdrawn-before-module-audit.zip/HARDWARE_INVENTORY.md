# RooCore hardware and Amazon purchase status

## עדכון מאומת אחרון — 2026-11-07

פרטי ההזמנה נבדקו בחשבון: XIAO ESP32S3 שלישייה, ELEGOO B072BL2VX1, XT30U B0CFJKK6BX, זוג TXB0104 B07GMF3BWR, GH1.25 B0H3Q98C58 ונתיכי QBGTFAK B07BC8DW3L נרכשו ב־7 בנובמבר; T-mini Plus B0BJ2LWDM9 נרכש בהזמנה נפרדת באותו יום. ערכת BOJACK B07T61SY9Y מהזמנת 31 באוקטובר כוללת 2N3904. רכישה אינה קבלה פיזית.

המעגל העדכני הוא [POWER_SHUTDOWN.md](POWER_SHUTDOWN.md): EN עם מחלק וטרנזיסטור, חזרה אוטומטית מעל סף מתח, ללא צורך במודול חדש לתפקוד הזה. המשתמש אינו קונה דיודות; מקור יחיד מהממיר, וניתוק פיזי של הזנת 5V לפני USB. Mini-DIN 7 לא נמצא בהזמנות. רשימת [AMAZON_ORDER.md](AMAZON_ORDER.md) גוברת על מצבי סל/רכישה היסטוריים בהמשך.

### להלן תיעוד היסטורי — אין להזמין לפיו


תרשים החיבורים, מפת הפינים המוצעת וסדר הבדיקות העדכניים: [WIRING_GUIDE.md](WIRING_GUIDE.md). טרם בוצעו בדיקות חומרה; סף ניתוק הסוללה ומיפוי המחברים הפיזיים עדיין פתוחים.

## רכישות בארץ — עדכון המשתמש 2026-11-07

המשתמש קנה **Pololu D36V28F5** וכן **מפסק MOSFET 2–20V/6A**. כמויות וקבלה פיזית לא נמסרו. לא להזמין שוב ממיר 5V או מפסק לפני בדיקת הרכיבים האלה. דגם המפסק המדויק עדיין חסר. D36V28F5 מחליף את הצעת 4872 ברכש אך דורש תכנון נפרד לסף ניתוק הסוללה דרך EN; אין להעתיק את מעגל הכיבוי הישן ללא התאמה. ראו AMAZON_ORDER.md.

**ACTIVE PURCHASE LIST: [AMAZON_ORDER.md](AMAZON_ORDER.md). Amazon-only purchasing supersedes ALL shopping instructions below, including Pololu purchases and the older two-regulator / Sense proposals. The sections below preserve inventory and planning history, not additional purchase instructions. The user reports completing an Amazon purchase on 2026-11-07; the glass fuse kit listing was verified, but physical delivery is not confirmed.**

Checked on 2026-11-06 against the signed-in Amazon.com order history and cart. This records purchase status, **not physical possession**. Prices and delivery estimates are snapshots. Do not treat an item in the cart as ordered, or an ordered item as on hand.

## מצב הקנייה — עדכון תיעוד 2026-11-07

### החלטת בקר — 2026-11-07

**עדכון אחרון — מצלמה נדחית להרחבה עתידית:** המשתמש הבהיר שאינו מבקש מצלמה בשלב הנוכחי והציג צילום מסך של XIAO ESP32S3 3PCS עם 8MB PSRAM ו־8MB Flash. המארז מתאים לכיוון הבקר שנבחר ומחליף ברשימת ההמלצות את שתי ערכות ה־Sense. פריט הקנייה הנוכחי: [XIAO ESP32S3 — מארז 3 יחידות, Amazon B0DJ6NQFKX](https://www.amazon.com/dp/B0DJ6NQFKX), בחירה ESP32S3 / 3PCS, כמות מארזים 1. מיועד לבקר אחד במערכת ועוד שני לוחות לספייר או לפיתוח; אין צורך במארז נוסף.

בצילום המסך שסיפק המשתמש ב־2026-11-07 מוצג מחיר $26.99 למארז ($9.00 ליחידה בקירוב), משלוח לישראל $16.58 וללא חיובי יבוא מוצגים. הסכום המחושב הוא $43.57 כולל המשלוח המוצג; מחיר הסל המשולב והחיוב הסופי לא אומתו. אין מצלמה במארז, ולא מוסיפים כעת מצלמה, כרטיס זיכרון או אביזרי צילום. יכולת מצלמה עתידית דורשת בחירת מודול וחיבור תואמים; אין להבטיח שהרחבת Sense מתחברת ישירות ללוח הרגיל. ההספק, ההגנות ומפת הפינים טרם הושלמו. **הרשימה עודכנה בלבד: לא נוסף לסל ולא הוזמן.**

#### בחירת Sense הקודמת — היסטוריה, הוחלפה לאחר הבהרת המשתמש

**עדכון דרישות מאוחר יותר באותו יום:** המשתמש ביקש מרווח עתידי למצלמה, חיישני גובה, חישובים מקומיים ושירות נתוני ליידר. בעקבות זאת ההמלצה המעודכנת היא [Seeed Studio XIAO ESP32-S3 Sense](https://www.seeedstudio.com/XIAO-ESP32S3-Sense-p-5639.html), ערכה הכוללת את לוח הרחבת המצלמה, עם 8MB PSRAM. **המשתמש אישר את הבחירה ב־S3 Sense.** לרשימת הקנייה נבחרו שתי יחידות בודדות של [XIAO ESP32-S3 Sense עם מצלמה ומיקרופון — Amazon B0C69FFVHH](https://www.amazon.com/dp/B0C69FFVHH), אחת למערכת ואחת ספייר. יש לבחור את האפשרויות ESP32S3 Sense ו־1PCS, בכמות הזמנה 2. לא נוסף לסל ולא הוזמן. אין לרכוש גם C3 וגם S3 עבור אותו תפקיד.

**בדיקת מארזים ומחיר, 2026-11-07:** לא נמצא מארז מאומת ומשתלם של 2–3 ערכות Sense מלאות באמזון. מארז השלישייה B0DJ6NQFKX הוא S3 רגיל, ולכן אינו תחליף לערכת Sense עם מצלמה. במפת האפשרויות של אמזון נמצאה גרסת Sense יחידה בלבד. מחיר הייחוס שנמצא ב־[PriceHistory](https://pricehistory.app/p/seeed-studio-xiao-esp32-s3-sense-2-iAoVDvce) הוא $23.99 ליחידה, כלומר $47.98 לשתיים לפני משלוח ומסים; זהו מחיר מתועד, לא מחיר חי מאומת בחשבון המשתמש. עמוד אמזון שנגיש לבדיקה לא הציג מחיר קנייה גלוי. לא אומתו משלוח לישראל, קופון או הנחת כמות. חלופת Pre-Soldered מספר B0DRNW6KMG נפסלה כקישור ראשי: למרות מחיר היסטורי של $19.95 ל־Sense, בבדיקה הנוכחית אמזון החזיר בחירה ב־C3, ולכן אי אפשר להסתמך עליה כרכישת Sense. דגם המצלמה המדויק והאביזרים המצורפים טעונים אימות מול ההצעה הנבחרת.

תכנון ההרחבה: שני UART לרומבה ולליידר, זוג קווים שמור לחיישני I²C, ובקרה מקומית לכיבוי ולמצבי תקלה. המצלמה מאפשרת צילום ושידור תמונה; קצב התמונה והעומס בשילוב הליידר דורשים בדיקה. מיפוי SLAM מלא וראייה ממוחשבת כבדה מיועדים לשרת חיצוני; אם יידרשו ברובוט ללא רשת, יש לתכנן מחשב Linux נוסף ומערכת הספק מתאימה. ה־S3 עדיין יהיה שימושי כבקר חיישנים ותקשורת.

לוח Sense הוא 21×17.8 מ״מ; עם הרחבת המצלמה היצרן מציין גובה של כ־15 מ״מ. המצלמה, המיקרופון ו־microSD צורכים פינים; במיוחד microSD משתמש ב־GPIO7/8/9 ובקו CS, ולכן אין להבטיח SD פעיל לצד כל חיבורי הבקרה בלי מפת פינים או הרחבה. דגם המצלמה בפועל עשוי להשתנות לפי מלאי וגרסת הערכה. אין לבחור S3 Plus בהנחה שהרחבת המצלמה של Sense מתחברת אליו: היצרן מציין במפורש שאינה תואמת למחבר שלו. מקורות: [מפרט משפחת S3](https://wiki.seeedstudio.com/xiao_esp32s3_getting_started/), [שיתוף הפינים והתאמת ההרחבות](https://wiki.seeedstudio.com/xiao_esp32s3_pin_multiplexing/), [מגבלות דרייבר המצלמה בזמן Wi-Fi](https://github.com/espressif/esp32-camera).

**המלצת C3 הקודמת — היסטוריה בלבד:** המשתמש אישר תחילה לעבור ל־ESP32-C3. הדגם שהומלץ היה [Seeed Studio XIAO ESP32C3, SKU 113991054](https://www.seeedstudio.com/Seeed-XIAO-ESP32C3-p-5431.html), שתי יחידות: אחת למערכת ואחת ספייר. **טרם הוזמן ולא נוסף לסל על ידי העוזר.** מחיר היצרן שנצפה היום: $4.90 ליחידה, לפני משלוח ומסים. ארבעת מודולי ESP-01S שבהזמנה הקודמת אינם ESP32-C3; אין ראיה שנרכש ESP32-C3 קודם לכן, והמשתמש אישר שהדגם שהוזמן היה ESP-01S.

הלוח בגודל 21×17.8 מ״מ, ללא האנטנה והחיווט. לשבב שני UART חומרתיים, המיועדים לרומבה ולליידר; יש להגדיר בתוכנה את הקצאת הפינים. חיישנים נוספים מסוג I²C יכולים לחלוק זוג קווים, בכפוף לכתובות, למתח ולמגבלות העומס. אין הבטחה לחיבור כל חיישן עתידי: שני חיבורי UART יהיו תפוסים, וללוח 11 פיני GPIO בלבד, שלושה מהם פיני אתחול. יש לשמור מקום להרחבת I²C בעת סגירת מפת החיבורים; טרם אושרה מפת פינים מלאה. הלוח מרכז את התקשורת בבקר אחד אך אינו מחליף את ממיר מתח הסוללה, ניתוק העומס, הגנת הפריקה או התאמת רמות המתח לרומבה. חומרת ההספק שבהמשך עדיין טיוטה ואינה רשימת קנייה סופית.

מקורות: [מפרט ומפת פינים של Seeed](https://wiki.seeedstudio.com/XIAO_ESP32C3_Getting_Started/), [שני בקרי UART לפי Espressif](https://docs.espressif.com/projects/esp-idf/en/latest/esp32c3/api-reference/peripherals/uart.html).

**הסל באמזון עודכן בפועל ב־6 בנובמבר; היום עודכן התיעוד בלבד.** כלי השליטה בדפדפן אינו זמין בשיחה כרגע, ולכן מצב הסל והמחירים לא אומתו מחדש ב־7 בנובמבר. לא בוצעה רכישה.

| מה עדיין צריך לקנות | כמות לקנייה | מצב לפי בדיקת אמזון האחרונה |
| --- | --- | --- |
| [Seeed Studio XIAO ESP32S3, ‏8MB PSRAM, מארז 3 — B0DJ6NQFKX](https://www.amazon.com/dp/B0DJ6NQFKX) | מארז אחד: 3 לוחות; אחד למערכת ושניים לספייר/פיתוח | מחליף את ערכות Sense; $26.99 ועוד $16.58 משלוח לפי צילום המשתמש; ללא מצלמה, לא נוסף לסל ולא הוזמן |
| YDLIDAR T-mini Plus | חיישן אחד | בסל |
| ערכת מחברי GH1.25 לחיישן | חבילה אחת עם ספיירים | בסל |
| QBGTFAK 5×20 מ״מ — B07BC8DW3L | 12 בתי נתיך עם חוטי 16AWG (הדף מציין 13A) ו־110 נתיכי זכוכית מהירים, כולל 2A | המשתמש דיווח שנרכש; טרם התקבל או נבדק. דירוג DC לבית הנתיך אינו מוצג בבירור; בחירת 2A טעונה אימות מול העומס והחיווט |
| מתאמי UART מסוג TXB0104 | חבילה אחת של 2 | בסל |
| מחברי מתח XT30U עם חוטים | חבילה אחת של 2 זוגות | בסל |
| ממירים מוגנים Pololu #4872 | 2 יחידות: אחת ל־5V ואחת ל־3.3V | נבחרו לרשימת ההשלמות; אינם בסל ולא הוזמנו |
| כבלי Mini-DIN ‏7 פינים, Adafruit #2438 | 2 יחידות, כולל ספייר אחד | נבחרו לרשימת ההשלמות; אינם בסל ולא הוזמנו |
| ELEGOO B072BL2VX1, ‏525 נגדים, 17 ערכים, 0.25W ו־1% | מארז; כולל 1k, 4.7k, 10k, 100k | רכישה מ־7 בנובמבר אומתה בדף חשבון אמזון. אין לקנות מחדש. מחליף את ההערות ההיסטוריות שלפיהן נגדים טרם הוזמנו. |

הסכום ההיסטורי של ששת המוצרים בסל בבדיקה האחרונה היה **$109.07 לפני משלוח ומסים**; מאז דווחה השלמת רכישה, ולכן אין להתייחס לסכום או לסטטוס הסל ההיסטורי כעדכניים. הנתיך המתאפס הישן הוסר. ערכת הדיודות, INA226, ממירי I²C, ממירי MP1584EN ולוחות הפלסטיק הועברו ל־Saved for later ואינם חלק מרשימת הרכישה הפעילה.

**אין לקנות מחדש** את החוטים, כיווץ החום, הטרנזיסטורים, לוחות הניסוי, מחברי Dupont, חומרי ההלחמה, האזיקונים ו־Dual Lock שכבר כלולים בהזמנת 31 באוקטובר. גם חמשת ממירי ה־3.3V הרגילים רשומים כמוזמנים; הם אינם מספקים הגנת פריקה מאומתת למסילה הקבועה ברובוט.

רשימת ההשלמות עדיין אינה אישור שהמערכת מוכנה לחיבור קבוע: מעגל ברירת־המחדל לכיבוי ה־LiDAR טרם הושלם ואומת, ומדידות הסוללה בזמן טעינה עדיין חסרות. דגם הבקר המומלץ נבחר לעיל; יש לסגור את מפת הפינים ואת מעגל ההספק לפני שמציגים את רשימת הקנייה כסופית לחלוטין.

## Ordered on 2026-10-31

The privately retained Amazon order record list 23 product lines and 24 purchased units; the solder wire line has quantity 2. As checked, packages showed estimated arrival on November 15–17, 2026, and some showed “Arrived at customs.” None was verified as delivered or physically received.

| Product | Order quantity | Listing contents or specification | Amazon |
| --- | ---: | --- | --- |
| 3M SJ3560 clear Dual Lock fastener | 1 | 1 in × 10 ft roll | [B00AQ6IS1G](https://www.amazon.com/dp/B00AQ6IS1G) |
| KAIWEETS flush wire cutters | 1 | 6 in | [B097SZRNJV](https://www.amazon.com/dp/B097SZRNJV) |
| Mini 3.3 V buck converter boards | 1 | 5 boards; 4.75–23 V input, 1.8 A output | [B0B779CGJQ](https://www.amazon.com/dp/B0B779CGJQ) |
| TUOFENG silicone wire | 1 | 18 AWG, six colors, 13.2 ft per color | [B07G744V5Z](https://www.amazon.com/dp/B07G744V5Z) |
| Adhesive lined heat shrink tubing kit | 1 | 5:1 shrink ratio | [B0FRNLQZJC](https://www.amazon.com/dp/B0FRNLQZJC) |
| KOTTO helping hands | 1 | Four arms, weighted base | [B07MDKXNPC](https://www.amazon.com/dp/B07MDKXNPC) |
| Breadboard and jumper wire kit | 1 | Two 830 point boards, two 400 point boards, 126 jumpers | [B0H17GR4S5](https://www.amazon.com/dp/B0H17GR4S5) |
| Black cable zip ties | 1 | 400 assorted ties | [B08TVLYB3Q](https://www.amazon.com/dp/B08TVLYB3Q) |
| Double sided PCB prototype kit | 1 | 164 pieces, six board sizes, headers and terminals | [B0HGY3TJ74](https://www.amazon.com/dp/B0HGY3TJ74) |
| Nettbe reusable cable ties | 1 | 60 hook and loop ties, 8 in | [B0CNWW1MK8](https://www.amazon.com/dp/B0CNWW1MK8) |
| BOJACK transistor assortment | 1 | 250 pieces, 10 values | [B07T61SY9Y](https://www.amazon.com/dp/B07T61SY9Y) |
| Slipdrive SSD sleeve | 1 | Small, black | [B09L558LRC](https://www.amazon.com/dp/B09L558LRC) |
| Kaisi silicone repair mat | 1 | 17.7 × 11.8 in | [B07DGVRYL3](https://www.amazon.com/dp/B07DGVRYL3) |
| MG Chemicals 8341 no clean flux paste dispenser | 1 | 10 mL, plunger and tip | [B00425FUW2](https://www.amazon.com/dp/B00425FUW2) |
| CERRXIAN OBD2 male connector to open wires | 1 | 16 pin, 5 ft / 1.5 m pigtail | [B0CXHLG31Q](https://www.amazon.com/dp/B0CXHLG31Q) |
| MAIYUM 63/37 rosin core solder wire | **2** | Each: 0.6 mm, 100 g | [B076QD1W9X](https://www.amazon.com/dp/B076QD1W9X) |
| USB4 USB-C cable | 1 | 1 ft, 40 Gbps, 240 W | [B0G23JRR86](https://www.amazon.com/dp/B0G23JRR86) |
| ENERJOUR silicone hookup wire | 1 | 22 AWG, six 26 ft spools, 156 ft total | [B0DWJSB65V](https://www.amazon.com/dp/B0DWJSB65V) |
| AstroAI DM130B multimeter | 1 | 4000 count, auto ranging | [B0842HTN8C](https://www.amazon.com/dp/B0842HTN8C) |
| TODOELEC Dupont jumper wire kit | 1 | 120 wires, 10 cm | [B0D56V6S8M](https://www.amazon.com/dp/B0D56V6S8M) |
| No clean liquid soldering flux and wick | 1 | Two 50 mL bottles plus desoldering wick | [B0D9KMYJ6R](https://www.amazon.com/dp/B0D9KMYJ6R) |
| ESP8266 ESP-01S Wi-Fi modules | 1 | Pack of four modules | [B09J2KPHTN](https://www.amazon.com/dp/B09J2KPHTN) |
| MG Chemicals 8341 no clean flux paste jar | 1 | 49 g / 50 mL | [B09FWB6L5L](https://www.amazon.com/dp/B09FWB6L5L) |

The current order details show **₪1,372.13**. The [original confirmation email](https://mail.google.com/mail/u/?authuser=thfcxv%40gmail.com#all/1a19394e96da3eac) showed **₪1,556.15**. The reason for this difference was not established; use the live order details for the current displayed total.

## Amazon cart after cleanup on 2026-11-06 — not ordered

Every listing has cart quantity **one**; packs already supply the requested small-part spares. The live cart snapshot on Nov. 6 showed **6 items, $109.07 before shipping and tax**; this is historical, not the current cart or order total.

| Product | Pack contents | Purpose | Price | Amazon |
| --- | --- | --- | ---: | --- |
| WayPonDEV YDLIDAR T-mini Plus | 1 sensor | Selected 360° LiDAR | $59.99 | [B0BJ2LWDM9](https://www.amazon.com/dp/B0BJ2LWDM9) |
| EGSCST GH1.25 connector kit | 180 pre-crimped leads and 2–9-pin housings | T-mini Plus 4-pin mating cable, with spares; **verify pin order** | $18.99 | [B0H3Q98C58](https://www.amazon.com/dp/B0H3Q98C58) |
| QBGTFAK 5×20 mm glass fuse kit | 12 inline holders, 16 AWG leads (listing states 13A); 110 fast-blow glass fuses, including 2A | User reports purchased Nov. 7; replaces both MINI fuse lines. Not physically received/inspected; holder DC rating not clearly stated. | $11.68 at check | [B07BC8DW3L](https://www.amazon.com/dp/B07BC8DW3L) |
| NOYITO TXB0104 UART level-shifter boards | 2 boards | Roomba 5 V TTL ↔ ESP32-C3 3.3 V UART, one spare; verify board wiring and cable loading | $7.99 | [B07GMF3BWR](https://www.amazon.com/dp/B07GMF3BWR) |
| Yiqigou prewired Amass XT30U | 2 male/female pairs, 18 AWG | Polarized detachable battery branch, one spare pair | $8.99 | [B0CFJKK6BX](https://www.amazon.com/dp/B0CFJKK6BX) |

The prior plug-in resettable-fuse assortment [B0D8S9F4TY](https://www.amazon.com/dp/B0D8S9F4TY) was **removed**, not merely saved. The plastic sheets, diode assortment, INA226 monitors, I²C level shifters, and MP1584EN bucks were moved to **Saved for later**. They are outside the active purchase: the sheets depend on physical fit; the diode kit and INA226 are optional; the I²C board is not the selected UART solution; and the MP1584EN listing does not expose the shutdown/low-voltage behavior needed here. Saved for later also contains unrelated personal items, which are outside this project.

## Proposed hardware plan and remaining purchases — 2026-11-06

**Status: historical power-design draft, not an approved final wiring or shopping plan.** The October 31 order shows future delivery; the six cart products above are not bought. The fuse kit was purchased separately per the user's report and replaces the old MINI fuse and holder lines. The user reports owning a Roomba 620 with a 3200 mAh NiMH battery; it was not physically inspected. The earlier claim that the user already owned an ESP32-C3 was incorrect: the ordered controllers are four ESP-01S modules. An ESP-01S can communicate with a compatible UART LiDAR alone; its single usable full hardware UART limits a combined Roomba plus LiDAR design.

### Buy only what is still missing

| Item | Quantity | Why and source |
| --- | ---: | --- |
| [Pololu D30V30MALCMA #4872](https://www.pololu.com/product/4872) | **2 boards**, one set to 5.0 V and one to 3.3 V | Both accept 3.3–45 V input, have adjustable low-voltage cutoff and an EN input, plus reverse-input, overcurrent, short-circuit, and thermal protection. These are the two protected rails. The manufacturer's direct site lists $39.95 each but shows rationed supply and permits backorders; [DigiKey marketplace #25935807](https://www.digikey.com/en/products/detail/pololu/4872/25935807) showed 102 in stock at $45.28 each on this check, with separate shipping possible. **Not in Amazon cart or ordered.** |
| [Adafruit 7-pin Mini-DIN iRobot cable #2438](https://www.adafruit.com/product/2438) | **2 cables**, one installed and one spare | Correct iRobot OI connector with unterminated leads. Adafruit showed $6.95 each and in stock. Confirm the 620 connector and pin mapping physically before wiring. **Not in Amazon cart or ordered.** |
| Through-hole resistor assortment with at least 1 kΩ, 10 kΩ, 100 kΩ at 0.25 W | **1 assortment**, not multiple packs | Needed to build and tune a hardware default-off EN control for the 5 V LiDAR rail with transistors from the already-ordered BOJACK kit. Do not choose resistor values for permanent wiring until the actual regulator EN node and ESP GPIO are bench-tested. **Not in Amazon cart or ordered.** |

Do **not** buy another pack of 3.3 V fixed bucks, 18/22 AWG wire, Dupont jumpers, heat-shrink, prototyping boards, transistors, solder, flux, cable ties, or Dual Lock: the October 31 order already contains ample quantities of each. The five ordered fixed 3.3 V buck boards are useful for bench work or other projects, but their listing says **23 V maximum input** and has no verified adjustable battery cutoff. They are **not** substitutes for the protected, permanently installed 3.3 V rail, so the two #4872 boards are not duplicate purchases. An extra third #4872 board is not necessary for this purchase plan. The one extra OI cable and the multipacks already in the cart cover inexpensive failure-prone connections.

### Electrical architecture and limits

- Power branch: verified Roomba battery solder taps → 18 AWG lead → 2 A 32 V MINI fuse **as close to the tap as practical** → XT30U → two separate #4872 regulators → 5 V LiDAR rail and 3.3 V ESP32-C3 rail. Common ground. The 2 A value is a **candidate**, not a validated final fuse size; confirm fault rating, actual load/startup current, holder fit, and wire routing before permanent assembly. The fuse protects wiring; the regulator protects its output.
- Configure each regulator's low-voltage cutoff against the actual NiMH battery and measured idle, cleaning, and charging voltages. It must recover only after the battery voltage rises. The maker says EN can also be pulled low to shut down and the hysteresis is about 200 mV; the startup voltage can be roughly 125% of the set cutoff. Do not set a fixed threshold from nominal 14.4 V alone. [Pololu #4872 details](https://www.pololu.com/product/4872).
- The 5 V regulator is **enabled by default** with battery input. Its EN pin alone does not guarantee the desired default-off LiDAR during ESP reset or sleep. Use the ordered transistor kit plus resistors to make a control circuit that holds 5 V off when GPIO is floating or low, but releases EN for normal low-voltage cutoff when GPIO explicitly commands on. **Circuit topology, values, and boot behavior remain to be bench-verified.** No claim of unattended-safe assembly until that test passes. The 3.3 V regulator stays on above cutoff so the controller can wake.
- The T-mini Plus calls for 4.8–5.2 V, up to 1 A startup, ~480 mA running, ~45 mA sleep, GH1.25-4P connector, and 3.3 V UART at 230400 baud. Disconnecting its 5 V rail when idle prevents that sleep draw. Verify the exact connector pin order; never use wire colors as proof. [YDLIDAR T-mini Plus data sheet](https://www.ydlidar.com/Public/upload/files/2024-05-24/YDLIDAR%20T-mini%20Plus%20Data%20Sheet_V1.1%20%28240131%29.pdf).
- Roomba OI is 0–5 V TTL UART, initially 115200 baud. The selected TXB0104 module is for short, push-pull UART connections, with 3.3 V and 5 V references; its 5 V reference can be powered by enabling the 5 V regulator before OI transactions. Check direction, power sequencing, and output levels on the bench. The OI Mini-DIN Vpwr pins are limited to 200 mA total continuously, so they are **not** the power feed for this system. The firmware must return the Roomba from Safe/Full to Passive/Stop for normal charging and sleep. [iRobot Roomba 600 OI specification](https://anrg.usc.edu/ee579/spring2016/Roomba/iRobot_Roomba_600_Open_Interface_Spec.pdf), [TI TXB0104](https://www.ti.com/product/TXB0104).
- The #4872 accepts up to 45 V input and has reverse-polarity protection up to 40 V, which gives far more margin than the ordered 23 V fixed buck. Still measure the actual battery-tap voltage and polarity in standby, cleaning, and while docked/charging before connecting electronics. Neither the output setting nor charging behavior has been tested on this Roomba. The ESP32-C3's exact board, pinout, and idle current are unverified. A low-voltage cutoff protects against deep discharge but does not make the parked system draw zero current. [Pololu #4872 details](https://www.pololu.com/product/4872).

### Readiness gate

Physical assembly can start when the six cart products and remaining parts above are received, but permanent battery integration remains conditional on measured battery/charging voltage, source-tap polarity, fuse/current verification, output adjustment to 5.0 and 3.3 V, LiDAR startup under load, default-off behavior through reset and sleep, ESP wake behavior, UART function, and safe return to charging mode. No Roomba or ESP was connected or used for these tests during this review.

## Other order visible in 2026 history

- 2026-09-24: Yubico Security Key C NFC, marked **cancelled** by Amazon. It is not RooCore stock.

## How to update this file

After receiving a package, record the date and verify its contents before marking any item **on hand**. Recheck the cart before planning purchases because it is temporary. The review covered the account's 2026 order history and current cart; older years were not reviewed.
