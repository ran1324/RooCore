# RooCore S3 power and purchase plan — 2026-11-07

Current shutdown design: [POWER_SHUTDOWN.md](POWER_SHUTDOWN.md). Uses purchased D36V28F5, automatic voltage recovery, one NPN and five resistors; bench calibration pending. User chose single-source 5V without a diode; disconnect the 5V feed before USB. The 4872 plan below is historical.


**Current assembly reference: [WIRING_GUIDE.md](WIRING_GUIDE.md).** It uses D36V28F5 and the purchased glass fuse kit, supplies a proposed S3 pin map, and explicitly marks unresolved battery cutoff and physical pin identification. The 4872 architecture below is historical and must not be followed for assembly.

**NEW PURCHASE OVERRIDE:** User reports buying D36V28F5 and an unidentified 2–20V/6A MOSFET switch locally. Do not buy 4872/2810 on the basis of this historical draft. D36V28F5 has fixed 5V output and requires external EN threshold circuitry for battery cutoff; its EN is internally pulled to VIN, so never connect it directly to an ESP32 GPIO. Switch identity and high-side/control/default-off behavior remain unverified. The architecture below is NOT a wiring guide for these new parts. Source: https://www.pololu.com/product/3782 .

**STATUS: Historical Pololu-based engineering draft, not an active shopping list. The user requires Amazon-only purchasing. See [AMAZON_ORDER.md](AMAZON_ORDER.md) for the authoritative deduplicated list and unresolved replacements. Do not buy the non-Amazon items below or transfer protection component values to a different converter without verification.**

Supersedes the old two-regulator proposal in HARDWARE_INVENTORY.md. Engineering design for bench validation, not a tested installation. **Fuse note:** the earlier MINI fuse and holder proposal was replaced by the user's reported purchase of QBGTFAK B07BC8DW3L (5×20 mm glass kit); see AMAZON_ORDER.md. The listing does not clearly state a DC voltage rating for its inline holder, so this remains a pre-installation verification item.

## Architecture
Battery tap -> 2A MINI fuse close to tap -> XT30 -> Pololu 4872 adjusted to 5.0V -> two branches:
1. Schottky 1N5819 (anode supply, band towards XIAO) -> XIAO ESP32S3 5V input. Its onboard regulator supplies 3.3V. Never connect the robot battery to BAT or 5V.
2. 1.25A fast fuse -> Pololu 2810 VIN -> switched OUT -> LiDAR 5V.
All grounds common. 2810 is after the regulator, never on robot battery. Slide switch remains OFF; ON input driven by GPIO with 10k pulldown. Regulator EN is left under its low-voltage circuitry, never forced high.

One master low-voltage cutoff removes power from both the 5V and onboard 3.3V rails. No second 4872 or additional fixed 3.3V buck is needed. Cutoff must be calibrated to the actual battery chemistry and measured voltages; nominal pack voltage alone is insufficient. Manufacturer reports restart near 125% of cutoff, so recharge may be required before restart. Shutdown current is nonzero; long storage requires unplugging XT30.

4872 provides input range up to 45V and reverse-input/current/thermal protection. This is voltage margin, not proof of charging-transient immunity. Proposed input TVS P6KE27A: band to fused VIN, other end GND; applicable only if measured normal charging voltage stays below its 23.1V standoff. Add 100uF 50V bulk capacitor at regulator input and another on master 5V before the switch. Observe polarity.

## Proposed pin allocation (plain XIAO S3, not Plus)
- D0 GPIO1 UART TX to Roomba through level shifter; D1 GPIO2 RX from Roomba.
- D6 GPIO43 TX to LiDAR; D7 GPIO44 RX from LiDAR, through separately enabled isolation board. Suppress console logs; boot logs must remain isolated.
- D4 GPIO5 SDA and D5 GPIO6 SCL reserved for future I2C sensors.
- D3 GPIO4 LiDAR switch ON, 10k pulldown.
- D8 GPIO7 LiDAR UART isolator OE, 10k pulldown.
- D9 GPIO8 Roomba BRC: 4.7k to base of existing-kit 2N3904, 10k base-emitter pulldown; emitter GND, collector BRC. Verify actual transistor pinout.
- D2 GPIO3 is a strapping pin; leave unconnected. D10 GPIO9 spare.

Use the two TXB0104 boards in the existing cart: first for short Roomba UART wiring, A supply XIAO 3.3V, B supply master 5V; second for LiDAR isolation, both A/B supplies XIAO 3.3V, OE controlled as above. Roomba board OE follows 3.3V via 10k; UART pads default to inputs until initialized. Verify actual module supply/OE labels and onboard decoupling before wiring. Do not use the full 6-foot OI cable: shorten signal wiring and verify waveforms; TXB0104 has limited capacitive drive. Additional pack gives two spare boards.

## Firmware contract — implementation still required
Boot/reset: switch OFF and LiDAR OE OFF. Set UART idle, confirm valid robot communications and available master power, then enable LiDAR power; after its startup interval enable UART and scanning. Stop/idle/dock/link-loss: stop scan, finish TX, disable OE, then switch power off. Before controller deep sleep ensure outputs release to pulldowns; wake via timer/reset. WiFi cannot receive immediate commands while in deep sleep. Return robot to Passive/Stop for its charging/sleep behavior. Hardware cutoff protects the added branch even if firmware stalls; sleep/idle switching still requires firmware. A watchdog/reset returns GPIO controls to OFF. USB programming with master power absent must never enable LiDAR OE.

## Purchase additions
| Item | Buy quantity | Link |
|---|---:|---|
| XIAO ESP32S3 3PCS, 8MB PSRAM | 1 pack | https://www.amazon.com/dp/B0DJ6NQFKX |
| Pololu D30V30MALCMA 4872 | 1 | https://www.pololu.com/product/4872 |
| Pololu Mini MOSFET switch LV 2810 | 2, one spare | https://www.pololu.com/product/2810 |
| Adafruit Mini-DIN 7-pin 2438 | 2, one spare | https://www.adafruit.com/product/2438 |
| 10k resistors, 25-pack | 1 pack | https://www.adafruit.com/product/2784 |
| 4.7k resistors, 25-pack | 1 pack | https://www.adafruit.com/product/2783 |
| Diodes Inc 1N5819-T | 5, spares included | https://www.digikey.com/en/products/detail/diodes-incorporated/1N5819-T/22056 |
| Littelfuse P6KE27A TVS | 2, one spare | https://www.digikey.com/en/products/detail/littelfuse-inc/P6KE27A/285935 |
| Panasonic EEU-FR1H101 100uF 50V | 5, two installed | https://www.digikey.com/en/products/detail/panasonic-electronic-components/EEU-FR1H101/2433588 |
| Littelfuse 02511.25MXL 1.25A fast axial fuse | 5 | https://www.digikey.com/en/products/detail/littelfuse-inc/02511-25MXL/700722 |
| TXB0104 two-board pack | add 1 pack to existing 1 (4 boards total) | https://www.amazon.com/dp/B07GMF3BWR |

Keep the previously recorded LiDAR, GH1.25 leads, MINI 2A fuses, holders and XT30 pack. Do not reorder wires, transistors, perfboards, insulation/heatshrink, solder or mounting Dual Lock. Camera excluded. 1N5819 spare may be used as output clamp (band to switched +5V, anode ground).

## Required before permanent connection
Battery label/chemistry, charging maximum and polarity; actual connector continuity and pin numbering; cutoff and recharge recovery; 4.8–5.2V at LiDAR during its 1A startup including fuse/cable drop (adjust master within permitted limits only); thermal/current tests; default OFF on reset and sleep; no UART backfeeding; reliable OI UART and normal docking. If measured battery voltage exceeds TVS standoff or tests expose excessive losses, component choice must be revised. Soldering iron and bench supply availability have not been established. This document cannot certify that no extra component will ever be needed before these measurements.

Sources: https://www.pololu.com/product/4872 ; https://www.pololu.com/product/2810 ; https://wiki.seeedstudio.com/xiao_esp32s3_pin_multiplexing/ ; https://www.ti.com/lit/ds/symlink/txb0104.pdf
