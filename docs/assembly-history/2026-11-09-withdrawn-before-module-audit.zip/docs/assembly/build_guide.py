from pathlib import Path
import html, json, csv, textwrap, shutil, xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
E = html.escape
source_origin=Path('/Users/ransaymour/Downloads/R3.MainPCA.Pwr.n.Gnd.pdf')
if source_origin.exists():
    (OUT/'sources').mkdir(exist_ok=True)
    shutil.copyfile(source_origin,OUT/'sources/R3.MainPCA.Pwr.n.Gnd.pdf')

def row(a, part, b): return (a, part, b)

steps = [
dict(id='01', title='מכינים חלק A — מעגל הכיבוי',
take='Q1 מסוג 2N3904; ‏R1/R5: שני נגדי 100kΩ; ‏R2: ‏4.7kΩ; ‏R3: ‏470Ω; ‏R4: ‏10kΩ. כל הנגדים 1%, ‏¼W. לוח הלחמה ופיסות חוט.',
before='זהה את רגלי B, C, E של הטרנזיסטור שסופק. הציור אינו קובע שמאל/אמצע/ימין. הכן צומתי A:EN, A:BASE, A:MID ו־A:GND: בכל צומת מחברים פיזית יחד את כל הקצוות בעלי אותו שם.',
rows=[row('A:VIN','R1 · 100kΩ','A:EN'),row('A:EN','R2 · 4.7kΩ','A:MID'),row('A:MID','R3 · 470Ω','A:GND'),row('A:D10','R4 · 10kΩ','A:BASE'),row('A:BASE','R5 · 100kΩ','A:GND'),row('Q1 · B','WIRE','A:BASE'),row('Q1 · C','WIRE','A:EN'),row('Q1 · E','WIRE','A:GND')],
after='השאר ארבעה חוטים מסומנים: A:VIN, A:EN, A:D10, A:GND. הצומת A:MID מחבר רק R2 ל־R3. בתוך הממיר יש כבר 100kΩ: אין להרכיב עותק נוסף שלו.',
note='R1–R3 הם ערכי ניסוי מהתכנון הקודם. הם נותנים בקירוב OFF=12.81V ו־ON=14.41V, לפני סטיות. השאר אותם נגישים להחלפה. אין לחבר לסוללה כפתרון מאושר לפני בדיקת התאוששות וכיול.'),
dict(id='02',title='מכינים חלק B — בקרת BRC לרומבה',
take='Q2 נוסף מסוג 2N3904; ‏R6: ‏4.7kΩ; ‏R7: ‏10kΩ; לוח הלחמה וחוטים.',
before='הכן צומת B:BASE וצומת B:GND. זהו טרנזיסטור נפרד מ־Q1. אין לחבר את הבסיסים או הקולטים של שני הטרנזיסטורים יחד.',
rows=[row('B:D9','R6 · 4.7kΩ','B:BASE'),row('B:BASE','R7 · 10kΩ','B:GND'),row('Q2 · B','WIRE','B:BASE'),row('Q2 · E','WIRE','B:GND'),row('Q2 · C','WIRE','B:BRC')],
after='השאר שלושה חוטים מסומנים: B:D9, B:BRC, B:GND. ‏D9 גבוה מפעיל את Q2 ומושך BRC נמוך.',
note='BRC הוא קו בקרה, לא קו הספק. התנהגות ההתעוררות תלויה בקושחת הרומבה. אין לחבר BRC ישירות ל־GPIO.'),
dict(id='03',title='מכינים חלק C — מתאם התקשורת לרומבה',
take='מודול NOYITO TXB0104 שנרכש, לבדיקה בלבד. אין לקחת או לקנות קבלים נוספים כעת. גם R10/R11 הם חלק מהתכנון העקרוני עד אימות המעגל שכבר קיים במודול.',
before='בתמונת המוצר מסומנים VCC ו־3V3, ואין OE מסומן במחברים. בתקריב של NOYITO B07GMF3BWR נראים שלושה קבלים קרמיים מולחמים בכל מודול: אחד אופקי מתחת לשבב ושניים אנכיים ליד הרכיב בעל שלוש הרגליים. ערכיהם ומסילותיהם לא אומתו. VCCA/VCCB/OE בציור הם אותות השבב בתכנון העקרוני, ולא מפת מחברים מאומתת של המודול שנרכש.',
rows=[row('C:3V3','WIRE','U1 · VCCA'),row('C:5V','WIRE','U1 · VCCB'),row('C:GND','WIRE','U1 · GND'),row('C:3V3','R10 · 10kΩ','U1 · OE'),row('U1 · OE','R11 · 100kΩ','C:GND')],
after='השאר את המודול ללא חיבור עד מיפוי המעגל שלו. אין להלחים R10/R11 או קבלים נוספים לפי הציור העקרוני הזה.',
note='שורות 6–7 הישנות עם C1/C2 בוטלו והוסרו. אין להוסיף את הקבלים ואין להחליף אותם בחוט. אין לחבר VCCA/VCCB לאדמה. יתר החיבורים כאן הם ייחוס בלבד עד מיפוי המודול שנרכש.'),
dict(id='04',title='מכינים חלק D — מתאם התקשורת לליידר',
take='מודול NOYITO TXB0104 שני, לבדיקה בלבד. אין לקחת קבלים חיצוניים או להלחים R9 בשלב זה.',
before='התכנון העקרוני דורש שני צדי 3.3V וגישה ל־OE לניתוק האותות כשהליידר כבוי. התאמת המודול שנרכש לדרישות האלה לא אומתה. אין להניח שהפד 3V3 הוא כניסה המותרת להזנה חיצונית.',
rows=[row('D:3V3','WIRE','U2 · VCCA'),row('D:3V3','WIRE','U2 · VCCB'),row('D:GND','WIRE','U2 · GND'),row('D:OE','WIRE','U2 · OE'),row('U2 · OE','R9 · 10kΩ','D:GND')],
after='השאר את U2 ללא חיבור עד אימות גישה ל־OE, מבנה ההזנה והתאמה לניתוק אותות הליידר. אין להוסיף קבלים בשלב הזה.',
note='שורות 6–7 הישנות עם C3/C4 בוטלו והוסרו. אין להוסיף את הקבלים ואין להחליף אותם בחוט. אין לחבר VCCA/VCCB לאדמה. יתר החיבורים כאן הם ייחוס בלבד עד מיפוי המודול שנרכש.'),
dict(id='05',title='מכינים חלק E — מפסק החשמל לליידר',
take='מפסק MOSFET, מסומן S1; ‏R8: ‏10kΩ; חוטים. ההוראות מותנות בזיהוי הלוח כ־Pololu #2810 או תואם חשמלי מאומת.',
before='זהה VIN, VOUT, GND, ON. השאר את מתג ההחלקה המובנה במצב OFF. ‏SW אינו קו הבקרה ל־XIAO.',
rows=[row('E:5V','WIRE','S1 · VIN'),row('S1 · VOUT','WIRE','E:5V_L'),row('E:GND','WIRE','S1 · GND'),row('E:ON','WIRE','S1 · ON'),row('S1 · ON','R8 · 10kΩ','E:GND')],
after='השאר ארבעה חוטים E:5V, E:5V_L, E:GND, E:ON. ‏SW נשאר ללא חיבור. ‏E:5V_L הוא הפלוס שיוצא לליידר.',
note='המפסק נמצא אחרי ממיר ה־5V. אין לחבר אותו ישירות למתח הסוללה בתכנון הזה. אין להוסיף טרנזיסטור כוח חיצוני: רכיבי ה־MOSFET כבר נמצאים על המודול.'),
dict(id='06',title='מכינים חלק F — צמת ההספק, ללא סוללה',
take='ממיר Pololu D36V28F5 מסומן U3; זוג XT30 מסומן J1; בית נתיך ונתיך F1 מאושרים לזרם ול־DC; חוטי הספק 18AWG; צומת חלוקה מבודד ל־GND.',
before='מקור ההספק הוא ענף נפרד מהסוללה, לא פינים 1/2 בשקע OI. אל תחבר עדיין את שני קצות המקור לרובוט. השאר F1 מחוץ לבית הנתיך בזמן ההרכבה.',
rows=[row('SOURCE + / VBAT','F1 · TBD','J1 source +'),row('J1 load +','WIRE','U3 · VIN'),row('SOURCE / SYS_RTN','WIRE','J1 source -'),row('J1 load -','WIRE','GND BUS'),row('GND BUS','WIRE','U3 · GND'),row('U3 · VOUT','WIRE','5V BUS')],
after='XT30 מחבר + אל + ו־− אל − כשמחברים את שני חצאיו. סמנו VIN_FUSED על יציאת + בצד העומס. הנתיך סמוך לנקודת ההזנה. ‏PG בממיר נשאר פנוי.',
note='2A הוא מועמד בלבד, לא ערך נתיך מאושר. הסימון 13A על בית הנתיך אינו ערך F1. יש לאמת דירוג DC, כושר ניתוק והתאמה לחוטים/התנעה. לפי סכמת R3, SOURCE− הוא SYS_RTN בצד המערכת של R235//R257, ולא J14/BAT−. אין לגשר ביניהם. זיהוי הפד הפיזי עדיין חסר.'),
dict(id='07a',title='מחברים את A–F יחד — קודם אדמות',
take='חלקים A, B, C, D, E, F; בקר XIAO ESP32S3; צומת GND מחלק F.',
before='הכל מנותק מסוללה, מטען ו־USB. ‏GND BUS הוא צומת מוליך משותף: מחברים אליו כל חוט מהרשימה. סמיכות בין פדים בלוח מחורר אינה חיבור.',
rows=[row(x,'WIRE','GND BUS') for x in ['A:GND','B:GND','C:GND','D:GND','E:GND','XIAO · GND']],
after='כעת כל האדמות של התוספת מחוברות. אדמת הליידר והרומבה מצטרפת בשלב 9. חזרת הזרם הראשית לרובוט עוברת בחוט ההספק אל SYS_RTN, לא דרך חוט התקשורת הדק.',
note='אין חוט מ־GND BUS ל־J14 בתכנון הזה. לפי הסכמה, J14 ו־SYS_RTN מופרדים על ידי נגד מדידת הזרם. זה מתקן את הסימון BAT−→GND במסמכים הישנים.'),
dict(id='07b',title='מחברים את A–F יחד — מסילות המתח',
take='החלקים שכבר חוברו לאדמה; חוטי הספק ותיוג.',
before='החיבורים בשלב הזה עדיין ללא מתח. שם BUS מציין נקודת חלוקה מוליכה משותפת, לא רכיב שצריך לקנות.',
rows=[row('U3 · VIN','WIRE','A:VIN'),row('U3 · EN','WIRE','A:EN'),row('5V BUS','WIRE','XIAO · 5V'),row('5V BUS','WIRE','C:5V'),row('5V BUS','WIRE','E:5V'),row('XIAO · 3V3','WIRE','C:3V3'),row('XIAO · 3V3','WIRE','D:3V3')],
after='ה־5V יוצא מהממיר. ה־3.3V יוצא מה־XIAO. אין ממיר 3.3V נוסף. ‏BAT ב־XIAO נשאר פנוי.',
note='מקור יחיד, בהתאם להחלטה ללא דיודה. לפני USB מנתקים פיזית את חוט ה־5V החיצוני ל־XIAO. ‏EN נמוך אינו ניתוק החוט. לצריבה ראשונה הפרד גם את חיבורי הרובוט והליידר.'),
dict(id='08',title='מחברים את הבקר לכל חלק',
take='XIAO ESP32S3 וחוטי האות המסומנים מהחלקים A–E.',
before='עבוד לפי הכיתוב D שעל הלוח, לא לפי מספר GPIO לבד ולא לפי מיקום בציור. חבר גם את האנטנה המצורפת לשקע האנטנה.',
rows=[row('XIAO D10 / GPIO9','WIRE','A:D10'),row('XIAO D9 / GPIO8','WIRE','B:D9'),row('XIAO D3 / GPIO4','WIRE','E:ON'),row('XIAO D8 / GPIO7','WIRE','D:OE'),row('XIAO D0 / GPIO1','WIRE','U1 · A1'),row('XIAO D1 / GPIO2','WIRE','U1 · A2'),row('XIAO D6 / GPIO43','WIRE','U2 · A1'),row('XIAO D7 / GPIO44','WIRE','U2 · A2')],
after='D2 נשאר פנוי; D4/D5 נשארים להרחבת I²C עתידית. אין חיבור ישיר מ־D10 ל־EN: הוא עובר דרך R4/Q1. ‏D10 אינו מחובר ל־OE של U1.',
note='TXB0104 דורש חיווט אותות קצר, ללא pull-up נוסף בקווי A/B. הוא אינו מבטיח תקשורת תקינה בכל אורך כבל. מפת הפינים תואמת לתיעוד המקומי; קושחה לא נצרבה או נבדקה כאן בחומרה.'),
dict(id='09',title='מכינים את שני כבלי הקצה',
take='כבל Mini-DIN 7 מתאים לרומבה; מחבר GH1.25-4P תואם לליידר. Mini-DIN 7 לא נמצא ברשימת ההזמנות המקומית.',
before='המחברים מנותקים מהמכשירים. מפה ברציפות כל פין לקצה החוט וסמן אותו. חזית שקע, חזית תקע וצד הלחמה אינם אותו מבט. אין להסיק מספר פין מצבע החוט.',
rows=[row('U1 · B1','WIRE','OI · 3 RXD'),row('OI · 4 TXD','WIRE','U1 · B2'),row('B:BRC','WIRE','OI · 5 BRC'),row('OI · 6 GND','WIRE','GND BUS'),row('OI · 7 GND','WIRE','GND BUS'),row('U2 · B1','WIRE','LiDAR · RX'),row('LiDAR · TX','WIRE','U2 · B2'),row('E:5V_L','WIRE','LiDAR · VCC'),row('LiDAR · GND','WIRE','GND BUS')],
after='בודד את פינים 1/2 של OI, כל אחד בנפרד. הליידר מקבל 5V מ־S1 ותקשורת ברמת 3.3V מ־U2. אין לחבר חוט בין A1 ל־B1 בתוך המתאם.',
note='חזרת זרם הליידר עוברת בחוט הספק מתאים ל־GND BUS. את המכשירים מחברים בשלבי הבדיקה, לא את כולם יחד לפני הפעלה ראשונה. מחבר OBD2 שנרכש אינו תחליף ל־Mini-DIN 7.'),
]

module_notice='תיקון 2026-11-09: שורות הקבלים C1–C4 בוטלו והוסרו מהתרשימים ומטבלאות ההרכבה. אין להוסיף אותם ואין להחליף אותם בחוט. אין כרגע דרישה לקנות קבלי 100nF. בתמונות התקריב המקוריות של NOYITO B07GMF3BWR זוהו שלושה קבלים קרמיים מולחמים בכל מודול; בגב הלוח מופיע WCMCU-401. ערכי הקיבול לא פורסמו במקורות שנבדקו, ולכן 100nF אינו ערך מאומת שלהם. זו בדיקת תמונות הדגם, לא בדיקה פיזית של היחידות שסופקו. סימוני VCC/3V3 והיעדר OE מסומן במחברים אינם תואמים למפה הכללית שהוצגה קודם. חיבורי U1/U2 וחלקים C/D הם תכנון ייחוס בלבד עד אימות המודול; אין לבצע אותם לפי התרשים הנוכחי.'
for s in steps:
    if s['id'] in {'03','04','07a','07b','08','09'}:
        s['reference_only']=True
        s['before']='חיבורי C/D ו־U1/U2 בשלב זה ממתינים למיפוי המודול שנרכש. '+s['before']
        if s['id'] not in {'03','04'}:
            s['note']='חיבורי המתאמים C/D בתרשים הם ייחוס בלבד עד אימות מודול NOYITO. '+s['note']
    if s['id'] in {'03','04'}:
        s['title']=s['title'].replace('מכינים חלק','ייחוס בלבד — חלק')

def make_diagram(s):
    n=len(s['rows']); footer=textwrap.wrap(s['note'], width=102); h=205+n*80+max(100,len(footer)*24)
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="{h}" viewBox="0 0 1080 {h}">', '<rect width="100%" height="100%" fill="#f7f9fc"/>']
    model=ET.Element('mxGraphModel',adaptiveColors='auto',page='1',pageWidth='1080',pageHeight=str(h));root=ET.SubElement(model,'root')
    ET.SubElement(root,'mxCell',id='0');ET.SubElement(root,'mxCell',id='1',parent='0')
    def box(id,x,y,w,hh,label,fill='#ffffff',stroke='#c4d0dc',size=19):
        svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{hh}" rx="8" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')
        svg.append(f'<text x="{x+w/2}" y="{y+hh/2+7}" text-anchor="middle" font-family="Arial,sans-serif" font-size="{size}" fill="#17314a">{E(label)}</text>')
        c=ET.SubElement(root,'mxCell',id=id,value=label,style=f'rounded=1;whiteSpace=wrap;html=1;fontSize={size};fillColor={fill};strokeColor={stroke};fontColor=#17314a;',vertex='1',parent='1')
        ET.SubElement(c,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(hh),**{'as':'geometry'})
    def edge(id,a,b,x1,x2,y,col='#596c7c'):
        svg.append(f'<line x1="{x1}" y1="{y}" x2="{x2}" y2="{y}" stroke="{col}" stroke-width="3"/>')
        for x in [x1,x2]: svg.append(f'<circle cx="{x}" cy="{y}" r="4" fill="{col}"/>')
        c=ET.SubElement(root,'mxCell',id=id,source=a,target=b,edge='1',parent='1',style=f'endArrow=none;html=1;strokeColor={col};strokeWidth=2;')
        ET.SubElement(c,'mxGeometry',relative='1',**{'as':'geometry'})
    box('title',20,15,1040,55,s['id']+' | '+s['title'],'#e8eff7','#e8eff7',25)
    legend='חיבורי C/D ו־U1/U2: ייחוס בלבד · לא להרכיב עד אימות המודול' if s.get('reference_only') else 'כל שורה היא חיבור אחד · כל התוויות הזהות באותו חלק מחוברות יחד'
    box('legend',20,82,1040,42,legend,'#fff2cc','#e1c46b',18)
    for i,(a,part,b) in enumerate(s['rows']):
        y=150+i*80
        box('a'+str(i),50,y,330,50,a)
        box('b'+str(i),700,y,330,50,b)
        if part=='WIRE':
            edge('e'+str(i),'a'+str(i),'b'+str(i),380,700,y+25)
            svg.append(f'<rect x="477" y="{y+7}" width="126" height="34" fill="#f7f9fc"/><text x="540" y="{y+30}" text-anchor="middle" font-family="Arial" font-size="17" fill="#596c7c">חוט / גשר</text>')
        else:
            fill='#e1f3ed' if part.startswith('C') else '#fff0cc'
            box('p'+str(i),435,y,210,50,part,fill,'#9b8548',19)
            edge('ea'+str(i),'a'+str(i),'p'+str(i),380,435,y+25)
            edge('eb'+str(i),'p'+str(i),'b'+str(i),645,700,y+25)
        svg.append(f'<text x="25" y="{y+30}" text-anchor="middle" font-family="Arial" font-size="17" fill="#718396">{i+1}</text>')
        c=ET.SubElement(root,'mxCell',id='num'+str(i),value=str(i+1),style='text;html=1;fontSize=17;fontColor=#718396;',vertex='1',parent='1')
        ET.SubElement(c,'mxGeometry',x='5',y=str(y+10),width='35',height='30',**{'as':'geometry'})
    fy=170+n*80
    svg.append(f'<rect x="20" y="{fy}" width="1040" height="{max(100,len(footer)*24)+15}" rx="8" fill="#fff2cc" stroke="#e1c46b"/>')
    for j,line in enumerate(footer):
        svg.append(f'<text x="1040" y="{fy+27+j*24}" text-anchor="start" direction="rtl" font-family="Arial,sans-serif" font-size="17" fill="#6b511b">{E(line)}</text>')
    c=ET.SubElement(root,'mxCell',id='limits',value=s['note'],style='rounded=1;whiteSpace=wrap;html=1;fontSize=17;fillColor=#fff2cc;strokeColor=#e1c46b;fontColor=#6b511b;spacing=12;',vertex='1',parent='1')
    ET.SubElement(c,'mxGeometry',x='20',y=str(fy),width='1040',height=str(max(100,len(footer)*24)+15),**{'as':'geometry'})
    svg.append('</svg>')
    (OUT/f'step-{s["id"]}.svg').write_text(''.join(svg))
    ET.ElementTree(model).write(OUT/f'step-{s["id"]}.drawio',encoding='utf-8',xml_declaration=True)
    return ''.join(svg),model

intro='''<p class="eyebrow">RooCore / חוברת הרכבה / 9 בנובמבר 2026</p><h1>בונים חלק אחד.<br>ואז מחברים את כולם.</h1>
<p class="lead">מדריך לחיבור XIAO ESP32S3, ליידר T-mini Plus ורומבה 620. בכל שלב: מה לקחת, איך לחבר כל קצה, ואילו חוטים להשאיר לשלב הבא.</p>
<div class="notice"><strong>מצב התכנון:</strong> חוברת הכנה ובדיקת שולחן. חלקים A/B/E ניתנים להכנה לאחר זיהוי הרכיבים. חלקים C/D וחיבורי המתאמים ממתינים למיפוי המודולים שנרכשו. חיבור קבוע לסוללה תלוי בזיהוי נקודת SYS_RTN, התאמת הנתיך, בדיקת ההפעלה של U1 וספי הכיבוי. הערכים הניסיוניים מסומנים במקום שבו משתמשים בהם.</div>
<p><strong>ההחלטה הקבועה:</strong> ענף הספק נפרד מהסוללה, עם פיוז משלנו וממיר 5V. שקע OI בן 7 פינים משמש לתקשורת ואדמה. פינים 1/2 שלו אינם מזינים את הפרויקט. אין דיודה נוספת ואין USB בהתקנה.</p>'''

prep='''<section id="prep"><h2>0 · מסדרים לפני שמלחימים</h2>
<ol><li>נתק את התוספת מכל מקור מתח, גם USB. עבוד על משטח מבודד.</li><li>סמן מדבקות: A כיבוי; B BRC; C מתאם רומבה; D מתאם ליידר; E מפסק ליידר; F הספק.</li><li>מדוד כל נגד בנפרד וסמן R1–R11. ‏470Ω אינו 470kΩ. לנגד רגיל אין כיוון; לטרנזיסטור יש B/C/E.</li><li>זהה את סימוני כל מודול ואת רגלי הטרנזיסטורים לפי הרכיבים שסופקו. אין מפת חורים להלחמה בלי מידות וסוג לוח הניסוי. בלוח פדים בודדים כל גשר צריך להתווסף במפורש.</li><li>בכל ציור קרא שורה משמאל לימין: קצה ראשון — הרכיב — קצה שני. שורות עם אותה תווית נפגשות באותה נקודה. WIRE הוא חוט, לא רכיב נוסף.</li></ol>
<p>התרשימים מציגים חיבורים חשמליים. מיקום המלבן אינו מיקום פד על המודול. אין לקבוע E/B/C לפי צורת TO-92 בלבד. דוגמת onsemi היא 1=E, 2=B, 3=C; היא אינה מאמתת את רכיבי BOJACK שסופקו.</p></section>'''

ground='''<section id="ground"><h2>החיבור לרומבה — שתי נקודות הספק וצמת OI</h2>
<div class="notice"><strong>תיקון בעקבות סכמת R3 שסופקה:</strong> J14/BAT− ו־SYS_RTN אינם אותה נקודת חיבור. ביניהם נמצא R235//R257, שנט מדידת זרם של כ־0.05Ω. פיני OI ‏6/7 מחוברים ל־SYS_RTN. חיבור האדמה שלנו גם ל־J14 וגם ל־OI עלול ליצור מעקף לשנט.</div>
<pre dir="ltr">BAT+ / J15 ── F1 ── XT30 (+) ── U3 VIN
                                      U3 VOUT ── 5V BUS
SYS_RTN ─────────── XT30 (−) ── GND BUS ── U3 GND
                                    └── OI 6/7

BAT− / J14 ── [R235 // R257 ≈ 0.05Ω] ── SYS_RTN
       NO added wire bridging this resistor</pre>
<p>זו עדיין הזנה מהסוללה. הפלוס מגיע מ־VBAT; חזרת הזרם מתחברת בצד המערכת כדי לשמור את חיישן הזרם במעגל. אין צורך להתחבר למנועים, לחיישנים או לבקרת המטען. נקודת SYS_RTN להספק צריכה להיות מתאימה לזרם; פיני OI אינם תחליף לחוט חזרת ההספק.</p>
<p>הסכמה מסומנת PRELIMINARY / DRAFT v.110726, וחלקים בה מסומנים כלא ידועים במלואם. יש להתאים את סימוני הלוח בפועל ולזהות את הפדים לפני הלחמה; לא מסיקים מיקום פד מהציור העקרוני.</p></section>'''

voltage='''<section id="measure"><h2>10 · מה כבר ידוע, ומה מודדים אצלך</h2>
<p>משתמשים במדריך השירות של סדרת 500 כבסיס לפלטפורמת R3 של ה־620. אין צורך לשחזר את בדיקות היצרן; אימות נקודתי נדרש לסוללה, לצמה ולמעגל הכיבוי שהוספנו.</p>
<table><thead><tr><th>מה</th><th>נתון קיים</th><th>מקור ומשמעות</th></tr></thead><tbody>
<tr><td>מתח סוללה בזמן ניקוי</td><td dir="ltr">~16–17V → 12V</td><td>הערה 3 בסכמת R3 שסופקה. 12V הוא קצה הטווח המתואר, לא סף חדש לתוספת.</td></tr>
<tr><td>בדיקת סוללה טעונה</td><td dir="ltr">15.5–18V</td><td>מדריך השירות, עמ׳ 8. נספח F בעמ׳ 72 משתמש בנפרד ב־14.5V כגבול כישלון במתקן הבדיקה.</td></tr>
<tr><td>נפילה בבדיקת עומס</td><td>לא יותר מ־2V</td><td>נספח F: מתקן עם עומס 5Ω, למספר שניות. זו אינה בדיקה עם נגדי ¼W שבערכה, ואינה הגדרת סף הכיבוי שלנו.</td></tr>
<tr><td>מטען / תחנה לפי הסכמה</td><td dir="ltr">22.5V / ~21.5V</td><td>נתוני כניסות טעינה; אינם מתח הסוללה ואינם נקודת ההזנה שבחרנו.</td></tr>
<tr><td>ממיר D36V28F5, פין EN</td><td dir="ltr">OFF &lt;1.20V; ON &gt;1.35V</td><td>נתוני Pololu. אלה מתחים על EN, לא על הסוללה.</td></tr>
<tr><td>חישוב למחלק R1–R3 הניסיוני</td><td dir="ltr">OFF ≈12.81V; ON ≈14.41V</td><td>חישוב נומינלי; אין כאן מדידה או אישור התאמה לסוללה.</td></tr>
<tr><td>בכניסת הליידר</td><td dir="ltr">4.8–5.2V</td><td>YDLIDAR. צריך להישמר גם בהתנעה; זרם שיא עד 1A ב־5V.</td></tr>
<tr><td>ביציאת XIAO ‏3V3</td><td dir="ltr">~3.3V</td><td>מסילת לוגיקה; אינה מקור הספק לליידר.</td></tr>
</tbody></table>
<p><strong>איך מודדים מתח:</strong> מולטימטר על V DC, שחור בשקע COM, אדום בשקע V/Ω. מודדים במקביל בין שתי הנקודות הרשומות. לא משתמשים בשקע A ולא במצב התנגדות על מעגל חי. בחיווט פתוח מחברים תפסים מבודדים כשהמתח מנותק, ורק אז מפעילים. אין להחזיק גששים חופשיים ברובוט נע.</p>
<p>מדידת מתח הסוללה עצמה היא בין J15/BAT+ ל־J14/BAT− המזוהים. מדידת המתח שהתוספת רואה היא בין U3 VIN ל־GND BUS. הם עשויים להיות שונים בגלל השנט והחיווט; אין לחבר את שתי האדמות בחוט כדי להשוות.</p>
<table><thead><tr><th>מדידה</th><th>נקודות / מצב</th><th>תוצאה למילוי</th></tr></thead><tbody>
<tr><td>M0</td><td>תווית סוללה: יצרן, כימיה, מתח, קיבולת, דגם</td><td><input aria-label="פרטי סוללה" placeholder="עדיין לא תועד"/></td></tr>
<tr><td>M1</td><td>מתח סוללה לאחר טעינה ובמנוחה</td><td><input aria-label="מתח מנוחה" placeholder="V"/></td></tr>
<tr><td>M2</td><td>מתח סוללה מרבי שנצפה בטעינה רגילה</td><td><input aria-label="מתח בטעינה" placeholder="V"/></td></tr>
<tr><td>M3</td><td>מתח מינימלי בהתחלת ניקוי רגיל ובזמן עבודה, לאחר הכנת מדידה בטוחה</td><td><input aria-label="מתח בעבודה" placeholder="V ומצב"/></td></tr>
<tr><td>M4</td><td>מתח לפני כיבוי עומס, מיד אחריו ולאחר 10/60 שניות; בלי לרוקן בכוונה מעבר לעצירה הרגילה</td><td><input aria-label="התאוששות מתח" placeholder="ארבע קריאות V"/></td></tr>
<tr><td>M5</td><td>בספק מעבדה: VIN שבו U3 נכבה בירידה / נדלק בעלייה, עם מחלק A</td><td><input aria-label="ספי ממיר" placeholder="OFF / ON"/></td></tr>
<tr><td>M6</td><td>LiDAR VCC מול GND בליידר, בהתחלה ובעבודה</td><td><input aria-label="מתח ליידר" placeholder="V מינימלי / מרבי"/></td></tr>
<tr><td>M7</td><td>השוואת מתח OI packet 22 מול מדידת סוללה ומול U3 VIN באותו מצב</td><td><input aria-label="הפרשי מדידה" placeholder="mV / מצב"/></td></tr>
</tbody></table>
<p>השדות אינם נשמרים אוטומטית. השתמש בכפתור הורדת המדידות כדי לשמור קובץ מקומי. מולטימטר יכול להחמיץ שקיעות קצרות; בדיקת קפיצות מתח/איכות UART עשויה לדרוש אוסצילוסקופ. אין לכייל לפי קריאה בודדת.</p>
<button id="save-measurements">הורדת המדידות כ־JSON</button>
<p><strong>בחירת הספים:</strong> סף תוכנה מעל סף הכיבוי החומרתי שנמדד; המתח לאחר הסרת העומס, עם מרווח שגיאה, מתחת לסף ההדלקה הנמוך ביותר שנמדד. אם אין מרווח יציב, משנים מחלק/תכנון לפני התקנה. חלוקת הנגדים הזו אינה נעילת כיבוי בסוללה מלאה ואינה זיהוי מטען.</p></section>'''

testing='''<section id="tests"><h2>11 · מחברים מתח בשלבים</h2><div class="notice">הפעלה עם U1/U2 ממתינה לאימות המודול שנרכש. רצף בדיקות התקשורת להלן הוא תכנון לבדיקה אחרי תיקון המיפוי, ולא הוראה לחבר את המודולים לפי המפה הכללית.</div><ol>
<li><strong>ללא מתח:</strong> בדוק כל שורה, ערך נגד, קוטביות, בידוד וקצר בין מסילות. סמן תווית לכל חוט.</li>
<li><strong>ממיר וחלק A בלבד:</strong> ספק מעבדה מוגבל זרם, עם טווח מתאים לתכנון. מדוד 5V, ספי EN והכיבוי. אין חיבור לרומבה או לליידר. את מגבלת הזרם מעלים רק בהתאם לעומס ולחיווט; אין ערך גורף לכל השלבים.</li>
<li><strong>XIAO בלבד:</strong> הוסף את הבקר ללא USB מקביל. מדוד 3V3. קושחת הבדיקה משאירה D3, D8, D10 נמוכים. הקושחה והכיול צריכים להתאים למפה לפני הפעלת פיני בקרה.</li>
<li><strong>S1 ואז ליידר:</strong> בדוק כיבוי/הדלקה ללא חיישן תחילה; הוסף ליידר כשהאותות מבודדים. מדוד את המתח במחבר שלו בהתנעה. אין לנתק GND כדי לכבות.</li>
<li><strong>מתאם U2:</strong> הפעל OE רק אחרי מתח יציב. לפני כיבוי ליידר: עצירת סריקה, D8 נמוך, ואז D3 נמוך. בדוק שאין הזנה דרך TX/RX כשהליידר כבוי.</li>
<li><strong>מתאם U1 ורומבה:</strong> בדוק OE בזמן עליית/ירידת המסילות ופתור את מגבלת תזמון U1 לפני שימוש קבוע. התחל בקריאת חיישנים בלבד; בדוק שאין הזנה חוזרת בכל מצבי כיבוי. אין פקודות תנועה בשלב הזה.</li>
<li><strong>כיול:</strong> מלא M0–M7. ודא שכיבוי התוספת נשאר כבוי לאחר התאוששות, והדלקה יציבה תחת עומס. נתוני OI מאפשרים רישום אוטומטי, אך הצלבה ראשונית במולטימטר נדרשת.</li>
<li><strong>התקנה:</strong> לאחר זיהוי הפדים ואישור הנתיך/הספים, חבר את ענף ההספק הנפרד. בידוד הלחמות, קיבוע נשלף ושחרור מאמץ. בדוק עגינה וטעינה ללא תנועה לפני שימוש רגיל.</li></ol></section>'''

caps='''<section id="caps"><h2>קבלים, פיוזים ומה לא מוסיפים</h2>
<p><strong>חיבורי C1–C4 בוטלו והוסרו מהתרשימים, מטבלת החיבורים ומרשימת החלקים. אין להוסיף אותם ואין להחליף אותם בחוט.</strong> אלה היו קבלי 100nF מדוגמת TI שהכנסתי בטעות להוראות ההרכבה בלי לאמת את הצורך בהם במודול שנרכש. בתמונות NOYITO B07GMF3BWR נראים שלושה קבלים קרמיים שכבר מולחמים בכל מודול. ערכיהם וחיבוריהם לא אומתו. אין לחבר VCCA או VCCB ישירות לאדמה.</p>
<table><thead><tr><th>מקום לסינון הספק נוסף</th><th>שני קצוות</th><th>מצב</th></tr></thead><tbody>
<tr><td>כניסת U3</td><td>VIN_FUSED ↔ GND BUS</td><td>ערך, סוג ומתח עבודה טרם נקבעו; לא להרכיב לפי ניחוש.</td></tr>
<tr><td>מסילת 5V לפני S1</td><td>5V BUS ↔ GND BUS</td><td>בחירה לאחר בדיקת חיווט/התנעה/קפיצות מתח.</td></tr>
<tr><td>בכניסת הליידר אחרי S1</td><td>E:5V_L ↔ LiDAR GND</td><td>בחירה לאחר בדיקה; קבל גדול גם מגדיל זרם חיבור.</td></tr></tbody></table>
<p>אלה מיקומי תכנון פתוחים, ולא קבלים בעלי ערך מאושר. אם ייבחר קבל אלקטרוליטי: פלוס למסילת המתח, מינוס ל־GND, ודירוג מתח מעל המתח המרבי כולל מרווח. הוא אינו מתחבר בטור עם חוט ההספק.</p>
<p>F1 הוא נתיך התוספת בלבד. נתיכי הרומבה ורכיבי המטען נשארים במקומם. אין צורך לפרק או להרכיב מחדש את רכיבי ה־SMD שבתוך המודולים. אין ESP-01S או ממיר 3.3V נוסף בתצורה הזאת; הלוחות הנוספים שנרכשו הם ספיירים. אין מצלמה או חיישני הרחבה בתכנון הנוכחי.</p></section>'''

sources=[('סכמת R3 שסופקה — PRELIMINARY, DRAFT v.110726','sources/R3.MainPCA.Pwr.n.Gnd.pdf'),('iRobot — מדריך שירות סדרת 500, עמ׳ 8, 22, 72–73','https://hallaweb.jlab.org/tech/Detectors/public_html/manuals/data_sheets-manuals/G-I/I/irobot/roomba_570.pdf'),('Pololu D36V28F5','https://www.pololu.com/product/3782'),('Pololu #2810','https://www.pololu.com/product/2810'),('Seeed XIAO ESP32S3','https://wiki.seeedstudio.com/xiao_esp32s3_getting_started/'),('TI TXB0104 — בעיקר סעיפים 9–10','https://www.ti.com/lit/ds/symlink/txb0104.pdf'),('YDLIDAR T-mini Plus','https://dedjh0j7jhutx.cloudfront.net/2036899223840006144/161db662c9e5a765435dfe03c4cd708e.pdf'),('iRobot OI 600 — מחבר ו־packet 22','https://cdn.hackaday.io/files/1835247851890816/2021-04-13_iRobot_Roomba_600_Open_Interface_Spec-3.pdf'),('onsemi 2N3904 — דוגמת מיפוי, לא אימות BOJACK','https://www.onsemi.com/pdf/datasheet/2n3903-d.pdf'),('ניסוי סוללה מקורי — מדגים התאוששות, אינו כיול לרובוט הזה','https://girr.org/random_stuff/roomba.html')]

css='''*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#eef2f6;color:#193147;font:17px/1.75 Arial,sans-serif}main{max-width:1100px;margin:auto;padding:36px 24px 90px}header{padding:28px 0}h1{font-size:52px;line-height:1.18;margin:14px 0}h2{font-size:28px;line-height:1.4;margin:0 0 18px}.eyebrow{font-size:14px;letter-spacing:.04em;color:#5d7286}.lead{font-size:21px;max-width:780px}section{background:white;border:1px solid #d7e0e8;border-radius:16px;margin:24px 0;padding:30px;scroll-margin-top:80px}.notice{background:#fff5dc;border-right:5px solid #c18a18;padding:16px 20px;border-radius:7px;margin:18px 0}nav{position:sticky;top:0;z-index:5;display:flex;gap:8px;flex-wrap:wrap;background:#eef2f6f5;padding:12px 0;border-bottom:1px solid #c9d6e0}a{color:#145c98}nav a,button{border:1px solid #aec0d0;border-radius:8px;padding:6px 12px;background:white;color:#193147;cursor:pointer;text-decoration:none;font:inherit}nav a:hover,button:hover{background:#dfebf6}li{margin:10px 0}.drawing{overflow:auto;margin:22px 0;border:1px solid #d2dce6;border-radius:12px;direction:ltr}.drawing svg{display:block;width:100%;height:auto;min-width:680px}.small{color:#63788b;font-size:14px}table{width:100%;border-collapse:collapse;font-size:15px}th,td{padding:10px 12px;text-align:right;border-bottom:1px solid #dce4eb;vertical-align:top}th{background:#eaf0f7}input{font:inherit;width:100%;min-width:110px;border:1px solid #b6c5d3;border-radius:4px;padding:8px}pre{background:#f1f5f9;padding:18px;overflow:auto;font:15px/1.8 monospace}.tag{display:inline-block;background:#e4edf6;border-radius:6px;padding:3px 10px;font-weight:bold}.check{display:flex;gap:10px;align-items:center}.check input{width:20px;min-width:20px;height:20px}.links{display:flex;flex-wrap:wrap;gap:14px}.source{font-size:14px}#search{width:100%;margin:12px 0}.hidden{display:none}@media(max-width:700px){main{padding:14px}h1{font-size:36px}section{padding:20px 14px}table{font-size:13px}th,td{padding:8px 5px}nav{position:static}h2{font-size:24px}}@media print{nav,button,#search,.links{display:none}body{background:white}main{padding:0}section{break-before:page;border:0;padding:0;margin:0 0 20px}.drawing{overflow:visible;border:0}.drawing svg{min-width:0}h1{font-size:36px}p,li{font-size:13px;line-height:1.5}.notice{font-size:13px}a{color:inherit}}'''

mxfile=ET.Element('mxfile',host='app.diagrams.net')
pinmodel=ET.parse(OUT.parent/'diagrams/pcb/06-xiao-layout.drawio').getroot()
for c in pinmodel.iter('mxCell'):
    if c.get('id')=='title': c.set('value','00 | מפת הפדים של XIAO ESP32S3')
pd=ET.SubElement(mxfile,'diagram',id='xiao-pinmap',name='00 מפת פדים XIAO');pd.append(pinmodel)
ET.ElementTree(pinmodel).write(OUT/'XIAO-pinmap.drawio',encoding='utf-8',xml_declaration=True)
pin=['<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="630" viewBox="0 0 1080 630"><rect width="1080" height="630" rx="12" fill="#f7f9fc"/><text x="540" y="40" text-anchor="middle" font-family="Arial" font-size="24" fill="#17314a">צד הרכיבים מולך · שקע USB למעלה</text><rect x="390" y="115" width="300" height="440" rx="20" fill="#46645a"/><rect x="485" y="85" width="110" height="70" rx="6" fill="#cad2d8" stroke="#697a88"/><text x="540" y="128" text-anchor="middle" font-family="Arial" font-size="24">USB-C</text><rect x="425" y="255" width="230" height="140" fill="#d9e0df"/><text x="540" y="315" text-anchor="middle" font-family="Arial" font-size="25">XIAO ESP32S3</text><text x="540" y="350" text-anchor="middle" font-family="Arial" font-size="20">TOP VIEW</text>']
left=['D0 / GPIO1','D1 / GPIO2','D2 / GPIO3','D3 / GPIO4','D4 / GPIO5','D5 / GPIO6','D6 / GPIO43']
right=['5V','GND','3V3 OUT','D10 / GPIO9','D9 / GPIO8','D8 / GPIO7','D7 / GPIO44']
for i,(a,b) in enumerate(zip(left,right)):
    y=190+i*52
    pin.append(f'<line x1="310" y1="{y}" x2="390" y2="{y}" stroke="#5b7183" stroke-width="2"/><line x1="690" y1="{y}" x2="770" y2="{y}" stroke="#5b7183" stroke-width="2"/><circle cx="390" cy="{y}" r="9" fill="#e9cc6d"/><circle cx="690" cy="{y}" r="9" fill="#e9cc6d"/><text x="292" y="{y+7}" text-anchor="end" font-family="Arial" font-size="22" fill="#17314a">{a}</text><text x="788" y="{y+7}" font-family="Arial" font-size="22" fill="#17314a">{b}</text>')
pin.append('<text x="540" y="600" text-anchor="middle" font-family="Arial" font-size="19" fill="#6b511b">BAT בגב נשאר פנוי · הזנה חיצונית מנותקת פיזית לפני USB</text></svg>')
pinsvg=''.join(pin)
(OUT/'XIAO-pinmap.svg').write_text(pinsvg)
prep=prep.replace('</section>',f'<div class="drawing">{pinsvg}</div><a href="XIAO-pinmap.drawio">מפת הפדים לעריכה</a></section>')
intro += '<div class="notice"><strong>קבלים ומודולי התקשורת:</strong> '+E(module_notice)+'</div>'
sources.append(('NOYITO B07GMF3BWR — תמונת המודול שנרכש', 'https://www.amazon.com/dp/B07GMF3BWR'))
sources.append(('NOYITO — תקריב מקורי: שלושה קבלים קרמיים על המודול', 'https://m.media-amazon.com/images/I/71vmdSIg9-L._AC_SL1500_.jpg'))
sections=[]
ledger=[]
for s in steps:
    svg,model=make_diagram(s)
    d=ET.SubElement(mxfile,'diagram',id='step'+s['id'],name=s['id']+' '+s['title']);d.append(model)
    sections.append(f'<section id="s{s["id"]}" class="assembly-step"><span class="tag">שלב {s["id"]}</span><h2>{E(s["title"])}</h2><p><strong>קח:</strong> {E(s["take"])}</p><p><strong>הכן:</strong> {E(s["before"])}</p><div class="drawing">{svg}</div><p><strong>בסיום:</strong> {E(s["after"])}</p><div class="notice">{E(s["note"])}</div><label class="check"><input type="checkbox"/>עברתי על השלב; חיבורי הייחוס אינם מאושרים להרכבה</label><p class="small">סימון ההתקדמות זמני בדף; אינו בדיקת חומרה.</p><div class="links"><a href="step-{s["id"]}.svg">תרשים SVG</a><a href="step-{s["id"]}.drawio">עריכה ב־draw.io</a></div></section>')
    ledger.extend([dict(step=s['id'],connection=i+1,first=a,component=p,last=b,status=('reference_only_module_mapping_pending' if s.get('reference_only') else 'bench_design_hardware_unverified')) for i,(a,p,b) in enumerate(s['rows'])])

ET.ElementTree(mxfile).write(OUT/'RooCore-assembly.drawio',encoding='utf-8',xml_declaration=True)
(OUT/'connections.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
with (OUT/'connections.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['step','connection','first','component','last','status']);w.writeheader();w.writerows(ledger)

bom='''<section id="bom"><h2>רשימת חלקים — בלי לספור ספיירים</h2><p><strong>R9/R10/R11 וחיבורי U1/U2 עדיין כפופים למיפוי המודול שנרכש. C1–C4 אינם חלקים נוספים ברשימת הקנייה.</strong></p><table><tr><th>סימון</th><th>רכיב</th><th>כמות</th></tr>
<tr><td>R1, R5, R11</td><td>100kΩ, ‏1%, ‏¼W</td><td>3</td></tr><tr><td>R4, R7, R8, R9, R10</td><td>10kΩ, ‏1%, ‏¼W</td><td>5</td></tr><tr><td>R2, R6</td><td>4.7kΩ, ‏1%, ‏¼W</td><td>2</td></tr><tr><td>R3</td><td>470Ω, ‏1%, ‏¼W</td><td>1</td></tr><tr><td>Q1, Q2</td><td>NPN 2N3904, סדר רגליים לאימות</td><td>2</td></tr><tr><td>U1, U2</td><td>מודול TXB0104</td><td>2</td></tr><tr><td>U3</td><td>Pololu D36V28F5</td><td>1</td></tr><tr><td>S1</td><td>מפסק MOSFET תואם #2810, טעון זיהוי</td><td>1</td></tr><tr><td>XIAO</td><td>ESP32S3 רגיל והאנטנה שלו</td><td>1</td></tr><tr><td>LiDAR</td><td>T-mini Plus</td><td>1</td></tr><tr><td>J1</td><td>זוג XT30</td><td>1 זוג</td></tr><tr><td>F1</td><td>בית נתיך + נתיך מאושרים ל־DC ולעומס; 2A מועמד</td><td>1</td></tr><tr><td>מחברים</td><td>Mini-DIN 7 לרומבה; GH1.25-4P לליידר</td><td>1 מכל סוג</td></tr><tr><td>חומרי הרכבה</td><td>חוטי הספק 18AWG; חוטי אות 22AWG קצרים; לוח הלחמה, מחברים, בידוד וכיווץ חום, קיבוע נשלף</td><td>לפי פריסה</td></tr></table><p>רכישה מתועדת אינה קבלה פיזית. קבלים חיצוניים ו־Mini-DIN 7 לא נמצאו ברשימת הרכש שנבדקה. אין כאן הזמנה או שינוי רשימת קניות.</p></section>'''
src='<section id="sources"><h2>מקורות ומצב האימות</h2><ul>'+''.join(f'<li class="source"><a href="{E(u)}">{E(t)}</a></li>' for t,u in sources)+'</ul><p>הצלבה עם HARDWARE_INVENTORY.md, AMAZON_ORDER.md, WIRING_GUIDE.md, POWER_SHUTDOWN.md ו־docs/POWER_SHUTDOWN.md. לא בוצעה מדידת חומרה, צריבה או הפעלת רובוט. קוד הקושחה אינו קיים בעותק המקומי שנבדק; מצב המימוש מובא מתיעוד הפרויקט.</p></section>'
nav='<nav><a href="#prep">התחלה</a>'+''.join(f'<a href="#s{s["id"]}">{s["id"]}</a>' for s in steps)+'<a href="#measure">מדידות</a><a href="#bom">רכיבים</a></nav>'
script='''document.querySelector('#search').addEventListener('input',e=>{const q=e.target.value.toLowerCase().trim();document.querySelectorAll('.assembly-step').forEach(s=>s.classList.toggle('hidden',q&&!s.textContent.toLowerCase().includes(q)))});document.querySelector('#save-measurements').onclick=()=>{const fields=[...document.querySelectorAll('#measure input')];const data={date:new Date().toISOString(),status:'user-entered; not verified',measurements:Object.fromEntries(fields.map(x=>[x.getAttribute('aria-label'),x.value]))};const a=document.createElement('a');const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.href=u;a.download='RooCore-measurements.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)};'''
page=f'<!doctype html><html lang="he" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><title>RooCore — חוברת הרכבה שלב אחרי שלב</title><style>{css}</style><main><header>{intro}<div class="links"><a href="RooCore-assembly.drawio">כל התרשימים לעריכה</a><a href="connections.csv">כל החיבורים בטבלה</a><button onclick="window.print()">הדפסה / שמירה ל־PDF</button></div></header>{nav}<input id="search" aria-label="חיפוש חלק" placeholder="חפש חלק: R4, Q1, U2, GND…"/>{prep}{ground}{"".join(sections)}{caps}{voltage}{testing}{bom}{src}</main><script>{script}</script></html>'
(OUT/'RooCore-assembly.html').write_text(page)

md=['# RooCore — הרכבה שלב אחרי שלב','עודכן 2026-11-09. [פתח את החוברת המאוירת](RooCore-assembly.html). [כל התרשימים לעריכה](RooCore-assembly.drawio).','', '**תיקון GND:** לפי סכמת R3 שסיפק המשתמש, J14/BAT− ו־SYS_RTN מופרדים בשנט R235//R257. לתוספת שמחוברת ל־OI יש להשתמש בחזרת הספק מזוהה אל SYS_RTN; אין להוסיף גשר ל־J14. נקודת החיבור הפיזית טרם אומתה.','', 'הספק נפרד מהסוללה דרך נתיך וממיר. OI פינים 1/2 אינם מחוברים. ערכי מחלק A, נתיך, סינון הספק ותזמון OE ב־U1 עדיין דורשים השלמה/אימות.']
md.extend(['', '**תיקון קבלים ומודולים:** '+module_notice])
for s in steps:
    md.extend(['',f'## {s["id"]} — {s["title"]}','',f'**קח:** {s["take"]}',f'**הכן:** {s["before"]}','',f'![תרשים שלב {s["id"]}](step-{s["id"]}.svg)','', '| חיבור | קצה ראשון | באמצע | קצה שני |','|---|---|---|---|'])
    md.extend(f'| {i+1} | {a} | {p} | {b} |' for i,(a,p,b) in enumerate(s['rows']))
    md.extend(['',f'**בסיום:** {s["after"]}',f'**שים לב:** {s["note"]}'])
md.extend(['','## מדידות ובדיקות','טבלאות המתחים, טופס M0–M7 וסדר בדיקות המתח מופיעים בחוברת HTML. הנתונים המקומיים עדיין ריקים; לא הוזנו תוצאות מדומות.','', '## מקורות']+[f'- [{t}]({u})' for t,u in sources])
(OUT/'README.md').write_text('\n'.join(md)+'\n')
parts=[r['component'].split(' · ')[0] for r in ledger if r['component']!='WIRE']
assert len([p for p in parts if p.startswith('R')])==11
assert set(p for p in parts if p.startswith('R'))=={f'R{i}' for i in range(1,12)}
assert not any(p.startswith('C') for p in parts), 'Cancelled external capacitors must not appear as assembly connections'
assert not any(r['component']=='WIRE' and 'VCC' in r['first'] and 'GND' in r['last'] for r in ledger), 'Removed capacitors must not be replaced by a wire'
assert all('J14' not in r['first']+r['last'] for r in ledger)
for f in OUT.glob('*.drawio'):
    if not f.name.startswith('._'): ET.parse(f)
for f in OUT.glob('*.svg'):
    if not f.name.startswith('._'): ET.parse(f)
print(f'Created {len(steps)} diagrams, {len(ledger)} connection rows, HTML, Markdown, CSV, JSON and draw.io bundle in {OUT}')
